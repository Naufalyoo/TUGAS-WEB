function scrollToSection(id){
  const target = document.getElementById(id);
  if(target) target.scrollIntoView({behavior:"smooth"});
}

document.addEventListener("DOMContentLoaded",()=>{
  const beratInput=document.getElementById("berat");
  const tinggiInput=document.getElementById("tinggi");
  const calcBtn=document.getElementById("calcBtn");
  const hasil=document.getElementById("hasilBMI");
  const advice=document.getElementById("advice");

  calcBtn.addEventListener("click",()=>{
    const berat=parseFloat(beratInput.value);
    const tinggi=parseFloat(tinggiInput.value)/100;

    if(isNaN(berat)||isNaN(tinggi)||berat<=0||tinggi<=0){
      hasil.innerHTML="Masukkan berat dan tinggi badan dengan benar!";
      advice.textContent="";
      hasil.style.color="#ff1900ff";
      return;
    }

    const bmi=(berat/(tinggi*tinggi)).toFixed(1);
    let status="",saran="",warna="#2c3e50";

    if(bmi<18.5){status="Kurus";saran="Cobalah makan lebih sering dengan porsi kecil tapi bergizi tinggi. Tambahkan makanan berprotein seperti telur, ayam, ikan, dan susu.";warna="#f1c40f";}
    else if(bmi<25){status="Normal";saran="Pertahankan pola hidup sehat! Konsumsi makanan seimbang dan rutin olahraga agar tubuh tetap fit.";warna="#27ae60";}
    else if(bmi<30){status="Gemuk";saran="Kurangi makanan tinggi gula dan lemak. Ganti camilan dengan buah segar dan rajin jalan kaki tiap hari.";warna="#e67e22";}
    else{status="Obesitas";saran="Segera atur pola makan, hindari fast food, dan mulai aktivitas fisik ringan. Konsultasi ke ahli gizi bila perlu.";warna="#e74c3c";}

    hasil.innerHTML=`BMI kamu : <b>${bmi}</b> (${status})`;
    hasil.style.color=warna;
    advice.textContent=saran;
    advice.style.color="#555";

    hasil.style.opacity="0";
    advice.style.opacity="0";
    setTimeout(()=>{
      hasil.style.transition="opacity 0.3s ease";
      advice.style.transition="opacity 0.5s ease";
      hasil.style.opacity="1";
      advice.style.opacity="1";
    },100);
  });
});

const hamburger=document.querySelector('.hamburger');
const navsec=document.querySelector('.navsec');

hamburger.addEventListener('click',()=>{
  hamburger.classList.toggle('open');
  navsec.classList.toggle('active');
  if(navsec.classList.contains('active')){
    document.body.style.overflow='hidden';
  }else{
    document.body.style.overflow='auto';
  }
});
